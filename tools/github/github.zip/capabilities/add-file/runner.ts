export const runner = async (input) => {
    const { accessToken, owner, repo, path, content, message, branch, sha } = input;
    if (!accessToken) {
      return {
        error: "Missing accessToken",
        status: 400
      };
    }
    try {
      const base64Content = btoa(unescape(encodeURIComponent(content)));
      const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
      const body = {
        message,
        content: base64Content
      };
      if (branch) {
        body.branch = branch;
      }
      if (sha) {
        body.sha = sha;
      }
      const response = await fetch(url, {
        method: "PUT",
        headers: {
          "Accept": "application/vnd.github+json",
          "Authorization": `Bearer ${accessToken}`,
          "X-GitHub-Api-Version": "2022-11-28",
          "User-Agent": "ATM-GitHub-Tool"
        },
        body: JSON.stringify(body)
      });
      const responseText = await response.text();
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (e) {
        return {
          error: responseText,
          status: response.status
        };
      }
      if (!response.ok) {
        return {
          error: data.message || "Failed to add file",
          status: response.status
        };
      }
      return {
        data: {
          content: {
            name: data.content.name,
            path: data.content.path,
            sha: data.content.sha,
            size: data.content.size,
            url: data.content.url,
            html_url: data.content.html_url,
            git_url: data.content.git_url,
            download_url: data.content.download_url,
            type: data.content.type
          },
          commit: {
            sha: data.commit.sha,
            url: data.commit.url,
            html_url: data.commit.html_url,
            message: data.commit.message
          }
        },
        status: 200
      };
    } catch (error) {
      return {
        error: "Failed to add file",
        details: error?.message || "Unknown error",
        status: 500
      };
    }
  };