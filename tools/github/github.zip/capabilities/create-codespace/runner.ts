export const runner = async (input) => {
    const { accessToken, owner, repo, ...params } = input;
    if (!accessToken) {
      return {
        error: "Missing accessToken",
        status: 400
      };
    }
    try {
      const url = `https://api.github.com/repos/${owner}/${repo}/codespaces`;
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Accept": "application/vnd.github+json",
          "Authorization": `Bearer ${accessToken}`,
          "X-GitHub-Api-Version": "2022-11-28",
          "User-Agent": "ATM-GitHub-Tool"
        },
        body: JSON.stringify(params)
      });
      const responseText = await response.text();
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (e) {
        return {
          error: responseText,
          status: response.status
        };
      }
      if (!response.ok) {
        return {
          error: data.message || "Failed to create codespace",
          status: response.status
        };
      }
      const previewUrl = data.web_url.replace(".github.dev", "-3000.app.github.dev");
      return {
        data: {
          web_url: data.web_url,
          preview_url: previewUrl
        },
        status: 200
      };
    } catch (error) {
      return {
        error: "Failed to create codespace",
        details: error?.message || "Unknown error",
        status: 500
      };
    }
  };