export const runner = async (input) => {
    const { accessToken, ...params } = input;
    if (!accessToken) {
      return {
        error: "Missing accessToken",
        status: 400
      };
    }
    try {
      const queryParams = new URLSearchParams();
      if (params.type)
        queryParams.append("type", params.type);
      if (params.sort)
        queryParams.append("sort", params.sort);
      if (params.direction)
        queryParams.append("direction", params.direction);
      if (params.per_page)
        queryParams.append("per_page", params.per_page.toString());
      if (params.page)
        queryParams.append("page", params.page.toString());
      const url = `https://api.github.com/user/repos${queryParams.toString() ? "?" + queryParams.toString() : ""}`;
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Accept": "application/vnd.github+json",
          "Authorization": `Bearer ${accessToken}`,
          "X-GitHub-Api-Version": "2022-11-28",
          "User-Agent": "ATM-GitHub-Tool"
        }
      });
      const responseText = await response.text();
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (e) {
        return {
          error: responseText,
          status: response.status
        };
      }
      if (!response.ok) {
        return {
          error: data.message || "Failed to list repositories",
          status: response.status
        };
      }
      return {
        data: data.map((repo) => ({
          id: repo.id,
          name: repo.name,
          full_name: repo.full_name,
          private: repo.private,
          html_url: repo.html_url,
          description: repo.description,
          fork: repo.fork,
          created_at: repo.created_at,
          updated_at: repo.updated_at,
          pushed_at: repo.pushed_at,
          language: repo.language,
          forks_count: repo.forks_count,
          stargazers_count: repo.stargazers_count,
          watchers_count: repo.watchers_count,
          default_branch: repo.default_branch,
          visibility: repo.visibility
        })),
        status: 200
      };
    } catch (error) {
      return {
        error: "Failed to list repositories",
        details: error?.message || "Unknown error",
        status: 500
      };
    }
  };