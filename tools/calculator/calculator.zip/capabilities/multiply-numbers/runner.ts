export const runner = async (params) => ({
    result: params.a * params.b,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });