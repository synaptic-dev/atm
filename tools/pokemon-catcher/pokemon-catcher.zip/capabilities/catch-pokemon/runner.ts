export const runner = async (params) => {
    const randomId = Math.floor(Math.random() * 1008) + 1;
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${randomId}/`);
    if (!response.ok) {
      throw new Error("Failed to catch Pokemon!");
    }
    const pokemon = await response.json();
    return {
      message: `${params.trainer_name ? params.trainer_name + " caught" : "You caught"} a wild ${pokemon.name}!`,
      pokemon: {
        id: pokemon.id,
        name: pokemon.name,
        height: pokemon.height / 10,
        // convert to meters
        weight: pokemon.weight / 10,
        // convert to kg
        sprite: pokemon.sprites.front_default,
        types: pokemon.types.map((t) => t.type.name)
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  };