export const runner = async () => ({
    answer: 42,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });